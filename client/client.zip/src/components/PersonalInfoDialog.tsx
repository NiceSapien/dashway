import { useState, useEffect } from "react"
import { useForm } from "react-hook-form"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "./ui/dialog"
import { Button } from "./ui/button"
import { Input } from "./ui/input"
import { Label } from "./ui/label"
import { PersonalInfo, addPersonalInfo, updatePersonalInfo } from "@/api/personalInfo"
import { useToast } from "@/hooks/useToast"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs"

interface PersonalInfoDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  profile?: PersonalInfo | null
  onSave: () => void
}

export function PersonalInfoDialog({ open, onOpenChange, profile, onSave }: PersonalInfoDialogProps) {
  const [loading, setLoading] = useState(false)
  const { toast } = useToast()

  const { register, handleSubmit, reset } = useForm({
    defaultValues: {
      profileName: "",
      firstName: "",
      lastName: "",
      email: "",
      phone: "",
      street: "",
      city: "",
      state: "",
      zipCode: "",
      country: "",
      dateOfBirth: "",
      socialSecurityNumber: "",
      passportNumber: "",
      driverLicenseNumber: ""
    }
  })

  useEffect(() => {
    if (profile) {
      reset({
        profileName: profile.profileName,
        firstName: profile.firstName,
        lastName: profile.lastName,
        email: profile.email,
        phone: profile.phone,
        street: profile.address.street,
        city: profile.address.city,
        state: profile.address.state,
        zipCode: profile.address.zipCode,
        country: profile.address.country,
        dateOfBirth: profile.dateOfBirth,
        socialSecurityNumber: profile.socialSecurityNumber,
        passportNumber: profile.passportNumber,
        driverLicenseNumber: profile.driverLicenseNumber
      })
    } else {
      reset({
        profileName: "",
        firstName: "",
        lastName: "",
        email: "",
        phone: "",
        street: "",
        city: "",
        state: "",
        zipCode: "",
        country: "United States",
        dateOfBirth: "",
        socialSecurityNumber: "",
        passportNumber: "",
        driverLicenseNumber: ""
      })
    }
  }, [profile, reset])

  const onSubmit = async (data: any) => {
    setLoading(true)
    try {
      const profileData = {
        profileName: data.profileName,
        firstName: data.firstName,
        lastName: data.lastName,
        email: data.email,
        phone: data.phone,
        address: {
          street: data.street,
          city: data.city,
          state: data.state,
          zipCode: data.zipCode,
          country: data.country
        },
        dateOfBirth: data.dateOfBirth,
        socialSecurityNumber: data.socialSecurityNumber,
        passportNumber: data.passportNumber,
        driverLicenseNumber: data.driverLicenseNumber
      }

      if (profile) {
        await updatePersonalInfo(profile._id, profileData)
        toast({
          title: "Success",
          description: "Profile updated successfully",
        })
      } else {
        await addPersonalInfo(profileData)
        toast({
          title: "Success",
          description: "Profile added successfully",
        })
      }

      onSave()
      onOpenChange(false)
    } catch (error) {
      console.error('Error saving profile:', error)
      toast({
        title: "Error",
        description: "Failed to save profile",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[700px] bg-white dark:bg-slate-900 max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>
            {profile ? 'Edit Profile' : 'Add New Profile'}
          </DialogTitle>
          <DialogDescription>
            {profile ? 'Update your personal information' : 'Add a new personal information profile'}
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
          <Tabs defaultValue="basic" className="w-full">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="basic">Basic Info</TabsTrigger>
              <TabsTrigger value="address">Address</TabsTrigger>
              <TabsTrigger value="identity">Identity</TabsTrigger>
            </TabsList>

            <TabsContent value="basic" className="space-y-4">
              <div className="grid gap-4">
                <div className="space-y-2">
                  <Label htmlFor="profileName">Profile Name</Label>
                  <Input
                    id="profileName"
                    placeholder="e.g., Personal, Work"
                    {...register("profileName", { required: true })}
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="firstName">First Name</Label>
                    <Input
                      id="firstName"
                      placeholder="John"
                      {...register("firstName", { required: true })}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="lastName">Last Name</Label>
                    <Input
                      id="lastName"
                      placeholder="Doe"
                      {...register("lastName", { required: true })}
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="email">Email</Label>
                  <Input
                    id="email"
                    type="email"
                    placeholder="john.doe@example.com"
                    {...register("email", { required: true })}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="phone">Phone</Label>
                  <Input
                    id="phone"
                    placeholder="+1 (555) 123-4567"
                    {...register("phone")}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="dateOfBirth">Date of Birth</Label>
                  <Input
                    id="dateOfBirth"
                    type="date"
                    {...register("dateOfBirth")}
                  />
                </div>
              </div>
            </TabsContent>

            <TabsContent value="address" className="space-y-4">
              <div className="grid gap-4">
                <div className="space-y-2">
                  <Label htmlFor="street">Street Address</Label>
                  <Input
                    id="street"
                    placeholder="123 Main St"
                    {...register("street")}
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="city">City</Label>
                    <Input
                      id="city"
                      placeholder="New York"
                      {...register("city")}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="state">State</Label>
                    <Input
                      id="state"
                      placeholder="NY"
                      {...register("state")}
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="zipCode">ZIP Code</Label>
                    <Input
                      id="zipCode"
                      placeholder="10001"
                      {...register("zipCode")}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="country">Country</Label>
                    <Input
                      id="country"
                      placeholder="United States"
                      {...register("country")}
                    />
                  </div>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="identity" className="space-y-4">
              <div className="grid gap-4">
                <div className="space-y-2">
                  <Label htmlFor="socialSecurityNumber">Social Security Number</Label>
                  <Input
                    id="socialSecurityNumber"
                    placeholder="XXX-XX-XXXX"
                    {...register("socialSecurityNumber")}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="passportNumber">Passport Number</Label>
                  <Input
                    id="passportNumber"
                    placeholder="A12345678"
                    {...register("passportNumber")}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="driverLicenseNumber">Driver's License Number</Label>
                  <Input
                    id="driverLicenseNumber"
                    placeholder="D123456789"
                    {...register("driverLicenseNumber")}
                  />
                </div>
              </div>
            </TabsContent>
          </Tabs>

          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit" disabled={loading}>
              {loading ? 'Saving...' : profile ? 'Update' : 'Save'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}