import { useState, useEffect } from "react"
import { useForm } from "react-hook-form"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "./ui/dialog"
import { Button } from "./ui/button"
import { Input } from "./ui/input"
import { Label } from "./ui/label"
import { PaymentCard, BankAccount, addPaymentCard, addBankAccount } from "@/api/payments"
import { useToast } from "@/hooks/useToast"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "./ui/select"

interface PaymentDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  payment?: PaymentCard | BankAccount | null
  type: 'card' | 'account'
  onSave: () => void
}

export function PaymentDialog({ open, onOpenChange, payment, type, onSave }: PaymentDialogProps) {
  const [loading, setLoading] = useState(false)
  const { toast } = useToast()

  const { register, handleSubmit, reset, setValue } = useForm()

  useEffect(() => {
    if (payment && type === 'card') {
      const card = payment as PaymentCard
      reset({
        nickname: card.nickname,
        cardNumber: card.cardNumber,
        expirationDate: card.expirationDate,
        cvv: card.cvv,
        cardholderName: card.cardholderName,
        cardType: card.cardType,
        street: card.billingAddress.street,
        city: card.billingAddress.city,
        state: card.billingAddress.state,
        zipCode: card.billingAddress.zipCode,
        country: card.billingAddress.country
      })
    } else if (payment && type === 'account') {
      const account = payment as BankAccount
      reset({
        nickname: account.nickname,
        bankName: account.bankName,
        accountType: account.accountType,
        accountNumber: account.accountNumber,
        routingNumber: account.routingNumber,
        accountHolderName: account.accountHolderName
      })
    } else {
      reset({})
    }
  }, [payment, type, reset])

  const onSubmit = async (data: any) => {
    setLoading(true)
    try {
      if (type === 'card') {
        const cardData = {
          nickname: data.nickname,
          cardNumber: data.cardNumber,
          expirationDate: data.expirationDate,
          cvv: data.cvv,
          cardholderName: data.cardholderName,
          cardType: data.cardType,
          billingAddress: {
            street: data.street,
            city: data.city,
            state: data.state,
            zipCode: data.zipCode,
            country: data.country
          }
        }
        await addPaymentCard(cardData)
        toast({
          title: "Success",
          description: "Credit card added successfully",
        })
      } else {
        const accountData = {
          nickname: data.nickname,
          bankName: data.bankName,
          accountType: data.accountType,
          accountNumber: data.accountNumber,
          routingNumber: data.routingNumber,
          accountHolderName: data.accountHolderName
        }
        await addBankAccount(accountData)
        toast({
          title: "Success",
          description: "Bank account added successfully",
        })
      }

      onSave()
      onOpenChange(false)
    } catch (error) {
      console.error('Error saving payment method:', error)
      toast({
        title: "Error",
        description: "Failed to save payment method",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[600px] bg-white dark:bg-slate-900 max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>
            {payment ? `Edit ${type === 'card' ? 'Credit Card' : 'Bank Account'}` : `Add New ${type === 'card' ? 'Credit Card' : 'Bank Account'}`}
          </DialogTitle>
          <DialogDescription>
            {payment ? `Update your ${type === 'card' ? 'credit card' : 'bank account'} information` : `Add a new ${type === 'card' ? 'credit card' : 'bank account'} to your vault`}
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
          {type === 'card' ? (
            <Tabs defaultValue="card" className="w-full">
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="card">Card Details</TabsTrigger>
                <TabsTrigger value="billing">Billing Address</TabsTrigger>
              </TabsList>

              <TabsContent value="card" className="space-y-4">
                <div className="grid gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="nickname">Card Nickname</Label>
                    <Input
                      id="nickname"
                      placeholder="e.g., Main Credit Card"
                      {...register("nickname", { required: true })}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="cardholderName">Cardholder Name</Label>
                    <Input
                      id="cardholderName"
                      placeholder="John Doe"
                      {...register("cardholderName", { required: true })}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="cardNumber">Card Number</Label>
                    <Input
                      id="cardNumber"
                      placeholder="1234 5678 9012 3456"
                      {...register("cardNumber", { required: true })}
                    />
                  </div>

                  <div className="grid grid-cols-3 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="expirationDate">Expiry Date</Label>
                      <Input
                        id="expirationDate"
                        placeholder="MM/YY"
                        {...register("expirationDate", { required: true })}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="cvv">CVV</Label>
                      <Input
                        id="cvv"
                        placeholder="123"
                        {...register("cvv", { required: true })}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="cardType">Card Type</Label>
                      <Select onValueChange={(value) => setValue("cardType", value)}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select type" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="visa">Visa</SelectItem>
                          <SelectItem value="mastercard">Mastercard</SelectItem>
                          <SelectItem value="amex">American Express</SelectItem>
                          <SelectItem value="discover">Discover</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="billing" className="space-y-4">
                <div className="grid gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="street">Street Address</Label>
                    <Input
                      id="street"
                      placeholder="123 Main St"
                      {...register("street")}
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="city">City</Label>
                      <Input
                        id="city"
                        placeholder="New York"
                        {...register("city")}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="state">State</Label>
                      <Input
                        id="state"
                        placeholder="NY"
                        {...register("state")}
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="zipCode">ZIP Code</Label>
                      <Input
                        id="zipCode"
                        placeholder="10001"
                        {...register("zipCode")}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="country">Country</Label>
                      <Input
                        id="country"
                        placeholder="United States"
                        {...register("country")}
                      />
                    </div>
                  </div>
                </div>
              </TabsContent>
            </Tabs>
          ) : (
            <div className="grid gap-4">
              <div className="space-y-2">
                <Label htmlFor="nickname">Account Nickname</Label>
                <Input
                  id="nickname"
                  placeholder="e.g., Main Checking"
                  {...register("nickname", { required: true })}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="bankName">Bank Name</Label>
                <Input
                  id="bankName"
                  placeholder="Chase Bank"
                  {...register("bankName", { required: true })}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="accountType">Account Type</Label>
                <Select onValueChange={(value) => setValue("accountType", value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="checking">Checking</SelectItem>
                    <SelectItem value="savings">Savings</SelectItem>
                    <SelectItem value="business">Business</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="accountHolderName">Account Holder Name</Label>
                <Input
                  id="accountHolderName"
                  placeholder="John Doe"
                  {...register("accountHolderName", { required: true })}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="accountNumber">Account Number</Label>
                <Input
                  id="accountNumber"
                  placeholder="1234567890"
                  {...register("accountNumber", { required: true })}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="routingNumber">Routing Number</Label>
                <Input
                  id="routingNumber"
                  placeholder="021000021"
                  {...register("routingNumber", { required: true })}
                />
              </div>
            </div>
          )}

          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit" disabled={loading}>
              {loading ? 'Saving...' : payment ? 'Update' : 'Save'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}