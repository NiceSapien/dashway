import { Link, useLocation } from "react-router-dom"
import { 
  Shield, 
  Key, 
  FileText, 
  User, 
  CreditCard, 
  Settings, 
  Home,
  ChevronRight
} from "lucide-react"
import { cn } from "@/lib/utils"
import {
  Sidebar as SidebarPrimitive,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarHeader,
  useSidebar
} from "./ui/sidebar"

const navigation = [
  { name: 'Dashboard', href: '/', icon: Home },
  { name: 'Passwords', href: '/passwords', icon: Key },
  { name: 'Secure Notes', href: '/notes', icon: FileText },
  { name: 'Personal Info', href: '/personal-info', icon: User },
  { name: 'Payments', href: '/payments', icon: CreditCard },
  { name: 'Security', href: '/security', icon: Shield },
  { name: 'Settings', href: '/settings', icon: Settings },
]

export function Sidebar() {
  const location = useLocation()
  const { state } = useSidebar()

  return (
    <SidebarPrimitive className="border-r bg-white/80 backdrop-blur-sm dark:bg-slate-900/80">
      <SidebarHeader className="border-b p-6">
        <div className="flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-gradient-to-br from-blue-600 to-indigo-600 text-white">
            <Shield className="h-6 w-6" />
          </div>
          {state === "expanded" && (
            <div>
              <h1 className="text-xl font-bold bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">
                SecureVault
              </h1>
              <p className="text-sm text-muted-foreground">Password Manager</p>
            </div>
          )}
        </div>
      </SidebarHeader>
      
      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupContent>
            <SidebarMenu>
              {navigation.map((item) => {
                const isActive = location.pathname === item.href
                return (
                  <SidebarMenuItem key={item.name}>
                    <SidebarMenuButton asChild isActive={isActive}>
                      <Link
                        to={item.href}
                        className={cn(
                          "flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium transition-all hover:bg-accent hover:text-accent-foreground",
                          isActive && "bg-gradient-to-r from-blue-50 to-indigo-50 text-blue-700 dark:from-blue-950 dark:to-indigo-950 dark:text-blue-300"
                        )}
                      >
                        <item.icon className="h-5 w-5" />
                        {state === "expanded" && (
                          <>
                            <span>{item.name}</span>
                            {isActive && <ChevronRight className="ml-auto h-4 w-4" />}
                          </>
                        )}
                      </Link>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                )
              })}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>
    </SidebarPrimitive>
  )
}