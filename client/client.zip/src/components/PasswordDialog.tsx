import { useState, useEffect } from "react"
import { useForm } from "react-hook-form"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "./ui/dialog"
import { Button } from "./ui/button"
import { Input } from "./ui/input"
import { Label } from "./ui/label"
import { Textarea } from "./ui/textarea"
import { Badge } from "./ui/badge"
import { Eye, EyeOff, Globe, X } from "lucide-react"
import { Password, addPassword, updatePassword } from "@/api/passwords"
import { useToast } from "@/hooks/useToast"

interface PasswordDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  password?: Password | null
  onSave: () => void
}

export function PasswordDialog({ open, onOpenChange, password, onSave }: PasswordDialogProps) {
  const [showPassword, setShowPassword] = useState(false)
  const [tags, setTags] = useState<string[]>([])
  const [tagInput, setTagInput] = useState("")
  const [loading, setLoading] = useState(false)
  const { toast } = useToast()

  const { register, handleSubmit, reset, setValue, watch } = useForm({
    defaultValues: {
      website: "",
      url: "",
      username: "",
      password: "",
      notes: "",
      folder: "Personal"
    }
  })

  const watchedPassword = watch("password")

  useEffect(() => {
    if (password) {
      reset({
        website: password.website,
        url: password.url,
        username: password.username,
        password: password.password,
        notes: password.notes,
        folder: password.folder
      })
      setTags(password.tags)
    } else {
      reset({
        website: "",
        url: "",
        username: "",
        password: "",
        notes: "",
        folder: "Personal"
      })
      setTags([])
    }
  }, [password, reset])

  const getPasswordStrength = (pwd: string) => {
    if (!pwd) return { strength: 'weak', score: 0 }
    
    let score = 0
    if (pwd.length >= 8) score += 1
    if (pwd.length >= 12) score += 1
    if (/[a-z]/.test(pwd)) score += 1
    if (/[A-Z]/.test(pwd)) score += 1
    if (/[0-9]/.test(pwd)) score += 1
    if (/[^A-Za-z0-9]/.test(pwd)) score += 1

    if (score <= 2) return { strength: 'weak', score: (score / 6) * 100 }
    if (score <= 4) return { strength: 'medium', score: (score / 6) * 100 }
    return { strength: 'strong', score: (score / 6) * 100 }
  }

  const passwordStrength = getPasswordStrength(watchedPassword)

  const addTag = () => {
    if (tagInput.trim() && !tags.includes(tagInput.trim())) {
      setTags([...tags, tagInput.trim()])
      setTagInput("")
    }
  }

  const removeTag = (tagToRemove: string) => {
    setTags(tags.filter(tag => tag !== tagToRemove))
  }

  const onSubmit = async (data: any) => {
    setLoading(true)
    try {
      const passwordData = {
        ...data,
        tags,
        isFavorite: password?.isFavorite || false
      }

      if (password) {
        await updatePassword(password._id, passwordData)
        toast({
          title: "Success",
          description: "Password updated successfully",
        })
      } else {
        await addPassword(passwordData)
        toast({
          title: "Success",
          description: "Password added successfully",
        })
      }

      onSave()
      onOpenChange(false)
    } catch (error) {
      console.error('Error saving password:', error)
      toast({
        title: "Error",
        description: "Failed to save password",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px] bg-white dark:bg-slate-900">
        <DialogHeader>
          <DialogTitle>
            {password ? 'Edit Password' : 'Add New Password'}
          </DialogTitle>
          <DialogDescription>
            {password ? 'Update your password information' : 'Add a new password to your vault'}
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
          <div className="grid gap-4">
            <div className="space-y-2">
              <Label htmlFor="website">Website Name</Label>
              <Input
                id="website"
                placeholder="e.g., Google, Facebook"
                {...register("website", { required: true })}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="url">Website URL</Label>
              <div className="relative">
                <Globe className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <Input
                  id="url"
                  placeholder="https://example.com"
                  className="pl-10"
                  {...register("url")}
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="username">Username/Email</Label>
              <Input
                id="username"
                placeholder="your@email.com"
                {...register("username", { required: true })}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="password">Password</Label>
              <div className="relative">
                <Input
                  id="password"
                  type={showPassword ? "text" : "password"}
                  placeholder="Enter password"
                  className="pr-10"
                  {...register("password", { required: true })}
                />
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  className="absolute right-0 top-0 h-full px-3 py-2 hover:bg-transparent"
                  onClick={() => setShowPassword(!showPassword)}
                >
                  {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </Button>
              </div>
              {watchedPassword && (
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-sm">
                    <span>Password Strength</span>
                    <Badge variant={passwordStrength.strength === 'strong' ? 'default' : passwordStrength.strength === 'medium' ? 'secondary' : 'destructive'}>
                      {passwordStrength.strength}
                    </Badge>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div
                      className={`h-2 rounded-full transition-all ${
                        passwordStrength.strength === 'strong' ? 'bg-green-500' :
                        passwordStrength.strength === 'medium' ? 'bg-yellow-500' : 'bg-red-500'
                      }`}
                      style={{ width: `${passwordStrength.score}%` }}
                    />
                  </div>
                </div>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="folder">Folder</Label>
              <Input
                id="folder"
                placeholder="Personal, Work, etc."
                {...register("folder")}
              />
            </div>

            <div className="space-y-2">
              <Label>Tags</Label>
              <div className="flex flex-wrap gap-2 mb-2">
                {tags.map((tag) => (
                  <Badge key={tag} variant="secondary" className="gap-1">
                    {tag}
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      className="h-auto p-0 hover:bg-transparent"
                      onClick={() => removeTag(tag)}
                    >
                      <X className="h-3 w-3" />
                    </Button>
                  </Badge>
                ))}
              </div>
              <div className="flex gap-2">
                <Input
                  placeholder="Add tag"
                  value={tagInput}
                  onChange={(e) => setTagInput(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), addTag())}
                />
                <Button type="button" variant="outline" onClick={addTag}>
                  Add
                </Button>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="notes">Notes</Label>
              <Textarea
                id="notes"
                placeholder="Additional notes (optional)"
                rows={3}
                {...register("notes")}
              />
            </div>
          </div>

          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit" disabled={loading}>
              {loading ? 'Saving...' : password ? 'Update' : 'Save'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}