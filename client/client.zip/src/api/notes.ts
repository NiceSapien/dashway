import api from './api';

export interface SecureNote {
  _id: string;
  title: string;
  content: string;
  category: 'personal' | 'work' | 'financial' | 'other';
  tags: string[];
  isFavorite: boolean;
  lastModified: string;
  createdAt: string;
}

// Description: Get all secure notes for the user
// Endpoint: GET /api/notes
// Request: {}
// Response: { notes: SecureNote[] }
export const getNotes = () => {
  // Mocking the response
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve({
        notes: [
          {
            _id: '1',
            title: 'WiFi Password',
            content: 'Network: HomeWiFi\nPassword: SuperSecure123!\nSecurity: WPA2',
            category: 'personal',
            tags: ['wifi', 'home'],
            isFavorite: true,
            lastModified: '2024-01-15T10:30:00Z',
            createdAt: '2024-01-01T09:00:00Z'
          },
          {
            _id: '2',
            title: 'Software License',
            content: 'Product: Adobe Creative Suite\nLicense Key: XXXX-XXXX-XXXX-XXXX\nPurchase Date: 2024-01-01',
            category: 'work',
            tags: ['software', 'license'],
            isFavorite: false,
            lastModified: '2024-01-10T14:20:00Z',
            createdAt: '2023-12-15T11:30:00Z'
          },
          {
            _id: '3',
            title: 'Insurance Information',
            content: 'Provider: State Farm\nPolicy Number: 123456789\nContact: 1-800-STATE-FARM',
            category: 'financial',
            tags: ['insurance', 'important'],
            isFavorite: true,
            lastModified: '2023-11-20T16:45:00Z',
            createdAt: '2023-06-10T08:15:00Z'
          }
        ]
      });
    }, 500);
  });
  // Uncomment the below lines to make an actual API call
  // try {
  //   return await api.get('/api/notes');
  // } catch (error) {
  //   throw new Error(error?.response?.data?.error || error.message);
  // }
};

// Description: Add a new secure note
// Endpoint: POST /api/notes
// Request: { title: string, content: string, category: string, tags: string[] }
// Response: { success: boolean, note: SecureNote }
export const addNote = (data: Omit<SecureNote, '_id' | 'lastModified' | 'createdAt'>) => {
  // Mocking the response
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve({
        success: true,
        note: {
          ...data,
          _id: Date.now().toString(),
          lastModified: new Date().toISOString(),
          createdAt: new Date().toISOString()
        }
      });
    }, 500);
  });
  // Uncomment the below lines to make an actual API call
  // try {
  //   return await api.post('/api/notes', data);
  // } catch (error) {
  //   throw new Error(error?.response?.data?.error || error.message);
  // }
};

// Description: Update an existing secure note
// Endpoint: PUT /api/notes/:id
// Request: { title: string, content: string, category: string, tags: string[] }
// Response: { success: boolean, note: SecureNote }
export const updateNote = (id: string, data: Partial<SecureNote>) => {
  // Mocking the response
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve({
        success: true,
        note: {
          ...data,
          _id: id,
          lastModified: new Date().toISOString()
        }
      });
    }, 500);
  });
  // Uncomment the below lines to make an actual API call
  // try {
  //   return await api.put(`/api/notes/${id}`, data);
  // } catch (error) {
  //   throw new Error(error?.response?.data?.error || error.message);
  // }
};

// Description: Delete a secure note
// Endpoint: DELETE /api/notes/:id
// Request: {}
// Response: { success: boolean }
export const deleteNote = (id: string) => {
  // Mocking the response
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve({ success: true });
    }, 500);
  });
  // Uncomment the below lines to make an actual API call
  // try {
  //   return await api.delete(`/api/notes/${id}`);
  // } catch (error) {
  //   throw new Error(error?.response?.data?.error || error.message);
  // }
};