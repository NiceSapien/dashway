import api from './api';

export interface PersonalInfo {
  _id: string;
  profileName: string;
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  address: {
    street: string;
    city: string;
    state: string;
    zipCode: string;
    country: string;
  };
  dateOfBirth: string;
  socialSecurityNumber: string;
  passportNumber: string;
  driverLicenseNumber: string;
  lastModified: string;
  createdAt: string;
}

// Description: Get all personal info profiles for the user
// Endpoint: GET /api/personal-info
// Request: {}
// Response: { profiles: PersonalInfo[] }
export const getPersonalInfo = () => {
  // Mocking the response
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve({
        profiles: [
          {
            _id: '1',
            profileName: 'Personal',
            firstName: 'John',
            lastName: 'Doe',
            email: 'john.doe@example.com',
            phone: '+1 (555) 123-4567',
            address: {
              street: '123 Main St',
              city: 'New York',
              state: 'NY',
              zipCode: '10001',
              country: 'United States'
            },
            dateOfBirth: '1990-01-15',
            socialSecurityNumber: 'XXX-XX-1234',
            passportNumber: 'A12345678',
            driverLicenseNumber: 'D123456789',
            lastModified: '2024-01-15T10:30:00Z',
            createdAt: '2024-01-01T09:00:00Z'
          },
          {
            _id: '2',
            profileName: 'Work',
            firstName: 'John',
            lastName: 'Doe',
            email: 'john.doe@company.com',
            phone: '+1 (555) 987-6543',
            address: {
              street: '456 Business Ave',
              city: 'New York',
              state: 'NY',
              zipCode: '10002',
              country: 'United States'
            },
            dateOfBirth: '1990-01-15',
            socialSecurityNumber: 'XXX-XX-1234',
            passportNumber: 'A12345678',
            driverLicenseNumber: 'D123456789',
            lastModified: '2024-01-10T14:20:00Z',
            createdAt: '2023-12-15T11:30:00Z'
          }
        ]
      });
    }, 500);
  });
  // Uncomment the below lines to make an actual API call
  // try {
  //   return await api.get('/api/personal-info');
  // } catch (error) {
  //   throw new Error(error?.response?.data?.error || error.message);
  // }
};

// Description: Add a new personal info profile
// Endpoint: POST /api/personal-info
// Request: PersonalInfo (without _id, lastModified, createdAt)
// Response: { success: boolean, profile: PersonalInfo }
export const addPersonalInfo = (data: Omit<PersonalInfo, '_id' | 'lastModified' | 'createdAt'>) => {
  // Mocking the response
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve({
        success: true,
        profile: {
          ...data,
          _id: Date.now().toString(),
          lastModified: new Date().toISOString(),
          createdAt: new Date().toISOString()
        }
      });
    }, 500);
  });
  // Uncomment the below lines to make an actual API call
  // try {
  //   return await api.post('/api/personal-info', data);
  // } catch (error) {
  //   throw new Error(error?.response?.data?.error || error.message);
  // }
};

// Description: Update an existing personal info profile
// Endpoint: PUT /api/personal-info/:id
// Request: Partial<PersonalInfo>
// Response: { success: boolean, profile: PersonalInfo }
export const updatePersonalInfo = (id: string, data: Partial<PersonalInfo>) => {
  // Mocking the response
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve({
        success: true,
        profile: {
          ...data,
          _id: id,
          lastModified: new Date().toISOString()
        }
      });
    }, 500);
  });
  // Uncomment the below lines to make an actual API call
  // try {
  //   return await api.put(`/api/personal-info/${id}`, data);
  // } catch (error) {
  //   throw new Error(error?.response?.data?.error || error.message);
  // }
};

// Description: Delete a personal info profile
// Endpoint: DELETE /api/personal-info/:id
// Request: {}
// Response: { success: boolean }
export const deletePersonalInfo = (id: string) => {
  // Mocking the response
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve({ success: true });
    }, 500);
  });
  // Uncomment the below lines to make an actual API call
  // try {
  //   return await api.delete(`/api/personal-info/${id}`);
  // } catch (error) {
  //   throw new Error(error?.response?.data?.error || error.message);
  // }
};