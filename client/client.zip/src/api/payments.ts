import api from './api';

export interface PaymentCard {
  _id: string;
  nickname: string;
  cardNumber: string;
  expirationDate: string;
  cvv: string;
  cardholderName: string;
  cardType: 'visa' | 'mastercard' | 'amex' | 'discover';
  billingAddress: {
    street: string;
    city: string;
    state: string;
    zipCode: string;
    country: string;
  };
  lastModified: string;
  createdAt: string;
}

export interface BankAccount {
  _id: string;
  nickname: string;
  bankName: string;
  accountType: 'checking' | 'savings' | 'business';
  accountNumber: string;
  routingNumber: string;
  accountHolderName: string;
  lastModified: string;
  createdAt: string;
}

// Description: Get all payment cards for the user
// Endpoint: GET /api/payments/cards
// Request: {}
// Response: { cards: PaymentCard[] }
export const getPaymentCards = () => {
  // Mocking the response
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve({
        cards: [
          {
            _id: '1',
            nickname: 'Main Credit Card',
            cardNumber: '**** **** **** 1234',
            expirationDate: '12/26',
            cvv: '***',
            cardholderName: 'John Doe',
            cardType: 'visa',
            billingAddress: {
              street: '123 Main St',
              city: 'New York',
              state: 'NY',
              zipCode: '10001',
              country: 'United States'
            },
            lastModified: '2024-01-15T10:30:00Z',
            createdAt: '2024-01-01T09:00:00Z'
          },
          {
            _id: '2',
            nickname: 'Business Card',
            cardNumber: '**** **** **** 5678',
            expirationDate: '08/25',
            cvv: '***',
            cardholderName: 'John Doe',
            cardType: 'mastercard',
            billingAddress: {
              street: '456 Business Ave',
              city: 'New York',
              state: 'NY',
              zipCode: '10002',
              country: 'United States'
            },
            lastModified: '2024-01-10T14:20:00Z',
            createdAt: '2023-12-15T11:30:00Z'
          }
        ]
      });
    }, 500);
  });
  // Uncomment the below lines to make an actual API call
  // try {
  //   return await api.get('/api/payments/cards');
  // } catch (error) {
  //   throw new Error(error?.response?.data?.error || error.message);
  // }
};

// Description: Get all bank accounts for the user
// Endpoint: GET /api/payments/accounts
// Request: {}
// Response: { accounts: BankAccount[] }
export const getBankAccounts = () => {
  // Mocking the response
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve({
        accounts: [
          {
            _id: '1',
            nickname: 'Main Checking',
            bankName: 'Chase Bank',
            accountType: 'checking',
            accountNumber: '****1234',
            routingNumber: '021000021',
            accountHolderName: 'John Doe',
            lastModified: '2024-01-15T10:30:00Z',
            createdAt: '2024-01-01T09:00:00Z'
          },
          {
            _id: '2',
            nickname: 'Savings Account',
            bankName: 'Bank of America',
            accountType: 'savings',
            accountNumber: '****5678',
            routingNumber: '011401533',
            accountHolderName: 'John Doe',
            lastModified: '2024-01-10T14:20:00Z',
            createdAt: '2023-12-15T11:30:00Z'
          }
        ]
      });
    }, 500);
  });
  // Uncomment the below lines to make an actual API call
  // try {
  //   return await api.get('/api/payments/accounts');
  // } catch (error) {
  //   throw new Error(error?.response?.data?.error || error.message);
  // }
};

// Description: Add a new payment card
// Endpoint: POST /api/payments/cards
// Request: PaymentCard (without _id, lastModified, createdAt)
// Response: { success: boolean, card: PaymentCard }
export const addPaymentCard = (data: Omit<PaymentCard, '_id' | 'lastModified' | 'createdAt'>) => {
  // Mocking the response
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve({
        success: true,
        card: {
          ...data,
          _id: Date.now().toString(),
          lastModified: new Date().toISOString(),
          createdAt: new Date().toISOString()
        }
      });
    }, 500);
  });
  // Uncomment the below lines to make an actual API call
  // try {
  //   return await api.post('/api/payments/cards', data);
  // } catch (error) {
  //   throw new Error(error?.response?.data?.error || error.message);
  // }
};

// Description: Add a new bank account
// Endpoint: POST /api/payments/accounts
// Request: BankAccount (without _id, lastModified, createdAt)
// Response: { success: boolean, account: BankAccount }
export const addBankAccount = (data: Omit<BankAccount, '_id' | 'lastModified' | 'createdAt'>) => {
  // Mocking the response
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve({
        success: true,
        account: {
          ...data,
          _id: Date.now().toString(),
          lastModified: new Date().toISOString(),
          createdAt: new Date().toISOString()
        }
      });
    }, 500);
  });
  // Uncomment the below lines to make an actual API call
  // try {
  //   return await api.post('/api/payments/accounts', data);
  // } catch (error) {
  //   throw new Error(error?.response?.data?.error || error.message);
  // }
};