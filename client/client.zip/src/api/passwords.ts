import api from './api';

export interface Password {
  _id: string;
  website: string;
  url: string;
  username: string;
  password: string;
  notes: string;
  tags: string[];
  folder: string;
  isFavorite: boolean;
  strength: 'weak' | 'medium' | 'strong';
  lastModified: string;
  createdAt: string;
}

// Description: Get all passwords for the user
// Endpoint: GET /api/passwords
// Request: {}
// Response: { passwords: Password[] }
export const getPasswords = () => {
  // Mocking the response
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve({
        passwords: [
          {
            _id: '1',
            website: 'Google',
            url: 'https://google.com',
            username: 'user@example.com',
            password: 'SecurePass123!',
            notes: 'Main Google account',
            tags: ['work', 'email'],
            folder: 'Work',
            isFavorite: true,
            strength: 'strong',
            lastModified: '2024-01-15T10:30:00Z',
            createdAt: '2024-01-01T09:00:00Z'
          },
          {
            _id: '2',
            website: 'GitHub',
            url: 'https://github.com',
            username: 'developer123',
            password: 'GitPass456!',
            notes: 'Development account',
            tags: ['development', 'code'],
            folder: 'Development',
            isFavorite: false,
            strength: 'strong',
            lastModified: '2024-01-10T14:20:00Z',
            createdAt: '2023-12-15T11:30:00Z'
          },
          {
            _id: '3',
            website: 'Facebook',
            url: 'https://facebook.com',
            username: 'user@example.com',
            password: 'weak123',
            notes: 'Personal social media',
            tags: ['social', 'personal'],
            folder: 'Personal',
            isFavorite: false,
            strength: 'weak',
            lastModified: '2023-11-20T16:45:00Z',
            createdAt: '2023-06-10T08:15:00Z'
          }
        ]
      });
    }, 500);
  });
  // Uncomment the below lines to make an actual API call
  // try {
  //   return await api.get('/api/passwords');
  // } catch (error) {
  //   throw new Error(error?.response?.data?.error || error.message);
  // }
};

// Description: Add a new password
// Endpoint: POST /api/passwords
// Request: { website: string, url: string, username: string, password: string, notes: string, tags: string[], folder: string }
// Response: { success: boolean, password: Password }
export const addPassword = (data: Omit<Password, '_id' | 'lastModified' | 'createdAt' | 'strength'>) => {
  // Mocking the response
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve({
        success: true,
        password: {
          ...data,
          _id: Date.now().toString(),
          strength: 'strong',
          lastModified: new Date().toISOString(),
          createdAt: new Date().toISOString()
        }
      });
    }, 500);
  });
  // Uncomment the below lines to make an actual API call
  // try {
  //   return await api.post('/api/passwords', data);
  // } catch (error) {
  //   throw new Error(error?.response?.data?.error || error.message);
  // }
};

// Description: Update an existing password
// Endpoint: PUT /api/passwords/:id
// Request: { website: string, url: string, username: string, password: string, notes: string, tags: string[], folder: string }
// Response: { success: boolean, password: Password }
export const updatePassword = (id: string, data: Partial<Password>) => {
  // Mocking the response
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve({
        success: true,
        password: {
          ...data,
          _id: id,
          lastModified: new Date().toISOString()
        }
      });
    }, 500);
  });
  // Uncomment the below lines to make an actual API call
  // try {
  //   return await api.put(`/api/passwords/${id}`, data);
  // } catch (error) {
  //   throw new Error(error?.response?.data?.error || error.message);
  // }
};

// Description: Delete a password
// Endpoint: DELETE /api/passwords/:id
// Request: {}
// Response: { success: boolean }
export const deletePassword = (id: string) => {
  // Mocking the response
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve({ success: true });
    }, 500);
  });
  // Uncomment the below lines to make an actual API call
  // try {
  //   return await api.delete(`/api/passwords/${id}`);
  // } catch (error) {
  //   throw new Error(error?.response?.data?.error || error.message);
  // }
};

// Description: Generate a secure password
// Endpoint: POST /api/passwords/generate
// Request: { length: number, includeUppercase: boolean, includeLowercase: boolean, includeNumbers: boolean, includeSymbols: boolean }
// Response: { password: string, strength: string }
export const generatePassword = (options: {
  length: number;
  includeUppercase: boolean;
  includeLowercase: boolean;
  includeNumbers: boolean;
  includeSymbols: boolean;
}) => {
  // Mocking the response
  return new Promise((resolve) => {
    setTimeout(() => {
      const chars = {
        uppercase: 'ABCDEFGHIJKLMNOPQRSTUVWXYZ',
        lowercase: 'abcdefghijklmnopqrstuvwxyz',
        numbers: '0123456789',
        symbols: '!@#$%^&*()_+-=[]{}|;:,.<>?'
      };
      
      let charset = '';
      if (options.includeUppercase) charset += chars.uppercase;
      if (options.includeLowercase) charset += chars.lowercase;
      if (options.includeNumbers) charset += chars.numbers;
      if (options.includeSymbols) charset += chars.symbols;
      
      let password = '';
      for (let i = 0; i < options.length; i++) {
        password += charset.charAt(Math.floor(Math.random() * charset.length));
      }
      
      resolve({
        password,
        strength: options.length >= 12 && options.includeUppercase && options.includeLowercase && options.includeNumbers && options.includeSymbols ? 'strong' : 'medium'
      });
    }, 300);
  });
  // Uncomment the below lines to make an actual API call
  // try {
  //   return await api.post('/api/passwords/generate', options);
  // } catch (error) {
  //   throw new Error(error?.response?.data?.error || error.message);
  // }
};