import api from './api';

export interface SecurityScore {
  overall: number;
  weakPasswords: number;
  reusedPasswords: number;
  oldPasswords: number;
  compromisedPasswords: number;
  twoFactorEnabled: boolean;
}

export interface SecurityIssue {
  _id: string;
  type: 'weak' | 'reused' | 'old' | 'compromised';
  passwordId: string;
  website: string;
  severity: 'low' | 'medium' | 'high' | 'critical';
  description: string;
  recommendation: string;
}

// Description: Get security score and analysis
// Endpoint: GET /api/security/score
// Request: {}
// Response: { score: SecurityScore }
export const getSecurityScore = () => {
  // Mocking the response
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve({
        score: {
          overall: 75,
          weakPasswords: 2,
          reusedPasswords: 1,
          oldPasswords: 3,
          compromisedPasswords: 0,
          twoFactorEnabled: false
        }
      });
    }, 500);
  });
  // Uncomment the below lines to make an actual API call
  // try {
  //   return await api.get('/api/security/score');
  // } catch (error) {
  //   throw new Error(error?.response?.data?.error || error.message);
  // }
};

// Description: Get security issues that need attention
// Endpoint: GET /api/security/issues
// Request: {}
// Response: { issues: SecurityIssue[] }
export const getSecurityIssues = () => {
  // Mocking the response
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve({
        issues: [
          {
            _id: '1',
            type: 'weak',
            passwordId: '3',
            website: 'Facebook',
            severity: 'high',
            description: 'This password is weak and easily guessable',
            recommendation: 'Use a stronger password with at least 12 characters, including uppercase, lowercase, numbers, and symbols'
          },
          {
            _id: '2',
            type: 'old',
            passwordId: '2',
            website: 'GitHub',
            severity: 'medium',
            description: 'This password is over 1 year old',
            recommendation: 'Consider updating this password for better security'
          },
          {
            _id: '3',
            type: 'reused',
            passwordId: '1',
            website: 'Google',
            severity: 'medium',
            description: 'This password is used on multiple sites',
            recommendation: 'Use unique passwords for each account'
          }
        ]
      });
    }, 500);
  });
  // Uncomment the below lines to make an actual API call
  // try {
  //   return await api.get('/api/security/issues');
  // } catch (error) {
  //   throw new Error(error?.response?.data?.error || error.message);
  // }
};

// Description: Run security audit
// Endpoint: POST /api/security/audit
// Request: {}
// Response: { success: boolean, issues: SecurityIssue[] }
export const runSecurityAudit = () => {
  // Mocking the response
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve({
        success: true,
        issues: [
          {
            _id: '1',
            type: 'weak',
            passwordId: '3',
            website: 'Facebook',
            severity: 'high',
            description: 'This password is weak and easily guessable',
            recommendation: 'Use a stronger password with at least 12 characters, including uppercase, lowercase, numbers, and symbols'
          }
        ]
      });
    }, 2000);
  });
  // Uncomment the below lines to make an actual API call
  // try {
  //   return await api.post('/api/security/audit');
  // } catch (error) {
  //   throw new Error(error?.response?.data?.error || error.message);
  // }
};