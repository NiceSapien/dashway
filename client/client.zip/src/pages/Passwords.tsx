import { useEffect, useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import {
  Search,
  Plus,
  Eye,
  EyeOff,
  Copy,
  Star,
  Edit,
  Trash2,
  Filter,
  Grid,
  List,
  ExternalLink
} from "lucide-react"
import { getPasswords, Password } from "@/api/passwords"
import { useToast } from "@/hooks/useToast"
import { PasswordDialog } from "@/components/PasswordDialog"
import { PasswordGenerator } from "@/components/PasswordGenerator"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export function Passwords() {
  const [passwords, setPasswords] = useState<Password[]>([])
  const [filteredPasswords, setFilteredPasswords] = useState<Password[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedPassword, setSelectedPassword] = useState<Password | null>(null)
  const [showPasswordDialog, setShowPasswordDialog] = useState(false)
  const [showGenerator, setShowGenerator] = useState(false)
  const [viewMode, setViewMode] = useState<'list' | 'grid'>('list')
  const [visiblePasswords, setVisiblePasswords] = useState<Set<string>>(new Set())
  const { toast } = useToast()

  useEffect(() => {
    const fetchPasswords = async () => {
      try {
        console.log('Fetching passwords...')
        const response = await getPasswords()
        setPasswords(response.passwords)
        setFilteredPasswords(response.passwords)
      } catch (error) {
        console.error('Error fetching passwords:', error)
        toast({
          title: "Error",
          description: "Failed to load passwords",
          variant: "destructive",
        })
      } finally {
        setLoading(false)
      }
    }

    fetchPasswords()
  }, [toast])

  useEffect(() => {
    const filtered = passwords.filter(password =>
      password.website.toLowerCase().includes(searchTerm.toLowerCase()) ||
      password.username.toLowerCase().includes(searchTerm.toLowerCase()) ||
      password.tags.some(tag => tag.toLowerCase().includes(searchTerm.toLowerCase()))
    )
    setFilteredPasswords(filtered)
  }, [searchTerm, passwords])

  const togglePasswordVisibility = (passwordId: string) => {
    const newVisible = new Set(visiblePasswords)
    if (newVisible.has(passwordId)) {
      newVisible.delete(passwordId)
    } else {
      newVisible.add(passwordId)
    }
    setVisiblePasswords(newVisible)
  }

  const copyToClipboard = async (text: string, type: string) => {
    try {
      await navigator.clipboard.writeText(text)
      toast({
        title: "Copied!",
        description: `${type} copied to clipboard`,
      })
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to copy to clipboard",
        variant: "destructive",
      })
    }
  }

  const handleEdit = (password: Password) => {
    setSelectedPassword(password)
    setShowPasswordDialog(true)
  }

  const handleAddNew = () => {
    setSelectedPassword(null)
    setShowPasswordDialog(true)
  }

  const getStrengthColor = (strength: string) => {
    switch (strength) {
      case 'strong': return 'bg-green-500'
      case 'medium': return 'bg-yellow-500'
      case 'weak': return 'bg-red-500'
      default: return 'bg-gray-500'
    }
  }

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="animate-pulse">
          <div className="h-8 bg-gray-200 rounded w-1/4 mb-4"></div>
          <div className="space-y-4">
            {[...Array(5)].map((_, i) => (
              <div key={i} className="h-20 bg-gray-200 rounded-lg"></div>
            ))}
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight bg-gradient-to-r from-slate-900 to-slate-600 dark:from-slate-100 dark:to-slate-400 bg-clip-text text-transparent">
            Passwords
          </h1>
          <p className="text-muted-foreground">
            Manage your passwords securely
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" onClick={() => setShowGenerator(true)}>
            Generate Password
          </Button>
          <Button onClick={handleAddNew}>
            <Plus className="h-4 w-4 mr-2" />
            Add Password
          </Button>
        </div>
      </div>

      <Card className="bg-white/60 backdrop-blur-sm border-0 shadow-lg">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                placeholder="Search passwords..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <div className="flex items-center gap-2">
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline" size="sm">
                    <Filter className="h-4 w-4 mr-2" />
                    Filter
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent>
                  <DropdownMenuItem>All Items</DropdownMenuItem>
                  <DropdownMenuItem>Favorites</DropdownMenuItem>
                  <DropdownMenuItem>Weak Passwords</DropdownMenuItem>
                  <DropdownMenuItem>Recently Used</DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
              <div className="flex border rounded-lg">
                <Button
                  variant={viewMode === 'list' ? 'default' : 'ghost'}
                  size="sm"
                  onClick={() => setViewMode('list')}
                >
                  <List className="h-4 w-4" />
                </Button>
                <Button
                  variant={viewMode === 'grid' ? 'default' : 'ghost'}
                  size="sm"
                  onClick={() => setViewMode('grid')}
                >
                  <Grid className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {viewMode === 'list' ? (
            <div className="space-y-3">
              {filteredPasswords.map((password) => (
                <div key={password._id} className="flex items-center gap-4 p-4 rounded-lg bg-white/50 dark:bg-slate-800/50 hover:bg-white/70 dark:hover:bg-slate-800/70 transition-colors">
                  <div className="w-10 h-10 rounded-full bg-gradient-to-br from-blue-500 to-indigo-500 flex items-center justify-center text-white font-medium">
                    {password.website.charAt(0).toUpperCase()}
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <h3 className="font-medium">{password.website}</h3>
                      {password.isFavorite && <Star className="h-4 w-4 text-yellow-500 fill-current" />}
                      <Badge variant={password.strength === 'strong' ? 'default' : password.strength === 'medium' ? 'secondary' : 'destructive'}>
                        {password.strength}
                      </Badge>
                    </div>
                    <p className="text-sm text-muted-foreground">{password.username}</p>
                    <div className="flex items-center gap-2 mt-1">
                      <span className="text-xs text-muted-foreground">
                        {visiblePasswords.has(password._id) ? password.password : '••••••••'}
                      </span>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => togglePasswordVisibility(password._id)}
                      >
                        {visiblePasswords.has(password._id) ? <EyeOff className="h-3 w-3" /> : <Eye className="h-3 w-3" />}
                      </Button>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Button variant="ghost" size="sm" onClick={() => copyToClipboard(password.username, 'Username')}>
                      <Copy className="h-4 w-4" />
                    </Button>
                    <Button variant="ghost" size="sm" onClick={() => copyToClipboard(password.password, 'Password')}>
                      <Copy className="h-4 w-4" />
                    </Button>
                    <Button variant="ghost" size="sm" onClick={() => window.open(password.url, '_blank')}>
                      <ExternalLink className="h-4 w-4" />
                    </Button>
                    <Button variant="ghost" size="sm" onClick={() => handleEdit(password)}>
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button variant="ghost" size="sm">
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {filteredPasswords.map((password) => (
                <Card key={password._id} className="bg-white/50 dark:bg-slate-800/50 hover:bg-white/70 dark:hover:bg-slate-800/70 transition-colors">
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div className="w-8 h-8 rounded-full bg-gradient-to-br from-blue-500 to-indigo-500 flex items-center justify-center text-white text-sm font-medium">
                          {password.website.charAt(0).toUpperCase()}
                        </div>
                        <div>
                          <h3 className="font-medium">{password.website}</h3>
                          <p className="text-xs text-muted-foreground">{password.username}</p>
                        </div>
                      </div>
                      {password.isFavorite && <Star className="h-4 w-4 text-yellow-500 fill-current" />}
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <Badge variant={password.strength === 'strong' ? 'default' : password.strength === 'medium' ? 'secondary' : 'destructive'}>
                          {password.strength}
                        </Badge>
                        <div className="flex items-center gap-1">
                          <Button variant="ghost" size="sm" onClick={() => copyToClipboard(password.username, 'Username')}>
                            <Copy className="h-3 w-3" />
                          </Button>
                          <Button variant="ghost" size="sm" onClick={() => copyToClipboard(password.password, 'Password')}>
                            <Copy className="h-3 w-3" />
                          </Button>
                          <Button variant="ghost" size="sm" onClick={() => handleEdit(password)}>
                            <Edit className="h-3 w-3" />
                          </Button>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs text-muted-foreground flex-1">
                          {visiblePasswords.has(password._id) ? password.password : '••••••••'}
                        </span>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => togglePasswordVisibility(password._id)}
                        >
                          {visiblePasswords.has(password._id) ? <EyeOff className="h-3 w-3" /> : <Eye className="h-3 w-3" />}
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      <PasswordDialog
        open={showPasswordDialog}
        onOpenChange={setShowPasswordDialog}
        password={selectedPassword}
        onSave={() => {
          setShowPasswordDialog(false)
          // Refresh passwords list
        }}
      />

      <PasswordGenerator
        open={showGenerator}
        onOpenChange={setShowGenerator}
      />
    </div>
  )
}