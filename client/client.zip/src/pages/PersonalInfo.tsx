import { useEffect, useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import {
  Search,
  Plus,
  Edit,
  Trash2,
  User,
  Mail,
  Phone,
  MapPin,
  CreditCard
} from "lucide-react"
import { getPersonalInfo, PersonalInfo as PersonalInfoType } from "@/api/personalInfo"
import { useToast } from "@/hooks/useToast"
import { PersonalInfoDialog } from "@/components/PersonalInfoDialog"

export function PersonalInfo() {
  const [profiles, setProfiles] = useState<PersonalInfoType[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedProfile, setSelectedProfile] = useState<PersonalInfoType | null>(null)
  const [showDialog, setShowDialog] = useState(false)
  const { toast } = useToast()

  useEffect(() => {
    const fetchProfiles = async () => {
      try {
        console.log('Fetching personal info profiles...')
        const response = await getPersonalInfo()
        setProfiles(response.profiles)
      } catch (error) {
        console.error('Error fetching personal info:', error)
        toast({
          title: "Error",
          description: "Failed to load personal information",
          variant: "destructive",
        })
      } finally {
        setLoading(false)
      }
    }

    fetchProfiles()
  }, [toast])

  const handleEdit = (profile: PersonalInfoType) => {
    setSelectedProfile(profile)
    setShowDialog(true)
  }

  const handleAddNew = () => {
    setSelectedProfile(null)
    setShowDialog(true)
  }

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="animate-pulse">
          <div className="h-8 bg-gray-200 rounded w-1/4 mb-4"></div>
          <div className="grid gap-6 md:grid-cols-2">
            {[...Array(2)].map((_, i) => (
              <div key={i} className="h-96 bg-gray-200 rounded-lg"></div>
            ))}
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight bg-gradient-to-r from-slate-900 to-slate-600 dark:from-slate-100 dark:to-slate-400 bg-clip-text text-transparent">
            Personal Information
          </h1>
          <p className="text-muted-foreground">
            Manage your personal profiles and information
          </p>
        </div>
        <Button onClick={handleAddNew}>
          <Plus className="h-4 w-4 mr-2" />
          Add Profile
        </Button>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        {profiles.map((profile) => (
          <Card key={profile._id} className="bg-white/60 backdrop-blur-sm border-0 shadow-lg hover:shadow-xl transition-all duration-300">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-full bg-gradient-to-br from-blue-500 to-indigo-500 flex items-center justify-center text-white">
                    <User className="h-6 w-6" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">{profile.profileName}</CardTitle>
                    <CardDescription>{profile.firstName} {profile.lastName}</CardDescription>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Button variant="ghost" size="sm" onClick={() => handleEdit(profile)}>
                    <Edit className="h-4 w-4" />
                  </Button>
                  <Button variant="ghost" size="sm">
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="grid gap-3">
                  <div className="flex items-center gap-3">
                    <Mail className="h-4 w-4 text-muted-foreground" />
                    <span className="text-sm">{profile.email}</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <Phone className="h-4 w-4 text-muted-foreground" />
                    <span className="text-sm">{profile.phone}</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <MapPin className="h-4 w-4 text-muted-foreground" />
                    <span className="text-sm">
                      {profile.address.city}, {profile.address.state} {profile.address.zipCode}
                    </span>
                  </div>
                </div>

                <div className="pt-4 border-t">
                  <h4 className="font-medium mb-2">Identity Information</h4>
                  <div className="grid gap-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Date of Birth:</span>
                      <span>{new Date(profile.dateOfBirth).toLocaleDateString()}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">SSN:</span>
                      <span>{profile.socialSecurityNumber}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Passport:</span>
                      <span>{profile.passportNumber}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Driver's License:</span>
                      <span>{profile.driverLicenseNumber}</span>
                    </div>
                  </div>
                </div>

                <div className="pt-2">
                  <p className="text-xs text-muted-foreground">
                    Last modified {new Date(profile.lastModified).toLocaleDateString()}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <PersonalInfoDialog
        open={showDialog}
        onOpenChange={setShowDialog}
        profile={selectedProfile}
        onSave={() => {
          setShowDialog(false)
          // Refresh profiles list
        }}
      />
    </div>
  )
}