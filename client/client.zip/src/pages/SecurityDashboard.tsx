import { useEffect, useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import {
  Shield,
  AlertTriangle,
  Clock,
  TrendingUp,
  CheckCircle,
  XCircle,
  RefreshCw
} from "lucide-react"
import { getSecurityScore, getSecurityIssues, runSecurityAudit, SecurityScore, SecurityIssue } from "@/api/security"
import { useToast } from "@/hooks/useToast"

export function SecurityDashboard() {
  const [securityScore, setSecurityScore] = useState<SecurityScore | null>(null)
  const [securityIssues, setSecurityIssues] = useState<SecurityIssue[]>([])
  const [loading, setLoading] = useState(true)
  const [auditLoading, setAuditLoading] = useState(false)
  const { toast } = useToast()

  useEffect(() => {
    const fetchSecurityData = async () => {
      try {
        console.log('Fetching security data...')
        const [scoreResponse, issuesResponse] = await Promise.all([
          getSecurityScore(),
          getSecurityIssues()
        ])
        setSecurityScore(scoreResponse.score)
        setSecurityIssues(issuesResponse.issues)
      } catch (error) {
        console.error('Error fetching security data:', error)
        toast({
          title: "Error",
          description: "Failed to load security data",
          variant: "destructive",
        })
      } finally {
        setLoading(false)
      }
    }

    fetchSecurityData()
  }, [toast])

  const handleRunAudit = async () => {
    setAuditLoading(true)
    try {
      console.log('Running security audit...')
      const response = await runSecurityAudit()
      setSecurityIssues(response.issues)
      toast({
        title: "Audit Complete",
        description: "Security audit completed successfully",
      })
    } catch (error) {
      console.error('Error running security audit:', error)
      toast({
        title: "Error",
        description: "Failed to run security audit",
        variant: "destructive",
      })
    } finally {
      setAuditLoading(false)
    }
  }

  const getScoreColor = (score: number) => {
    if (score >= 80) return "text-green-600"
    if (score >= 60) return "text-yellow-600"
    return "text-red-600"
  }

  const getScoreBackground = (score: number) => {
    if (score >= 80) return "from-green-500 to-emerald-500"
    if (score >= 60) return "from-yellow-500 to-orange-500"
    return "from-red-500 to-pink-500"
  }

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'critical': return 'destructive'
      case 'high': return 'destructive'
      case 'medium': return 'secondary'
      case 'low': return 'outline'
      default: return 'outline'
    }
  }

  const getSeverityIcon = (severity: string) => {
    switch (severity) {
      case 'critical':
      case 'high':
        return <XCircle className="h-4 w-4 text-red-500" />
      case 'medium':
        return <AlertTriangle className="h-4 w-4 text-yellow-500" />
      case 'low':
        return <CheckCircle className="h-4 w-4 text-green-500" />
      default:
        return <AlertTriangle className="h-4 w-4 text-gray-500" />
    }
  }

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="animate-pulse">
          <div className="h-8 bg-gray-200 rounded w-1/4 mb-4"></div>
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
            {[...Array(4)].map((_, i) => (
              <div key={i} className="h-32 bg-gray-200 rounded-lg"></div>
            ))}
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight bg-gradient-to-r from-slate-900 to-slate-600 dark:from-slate-100 dark:to-slate-400 bg-clip-text text-transparent">
            Security Dashboard
          </h1>
          <p className="text-muted-foreground">
            Monitor and improve your password security
          </p>
        </div>
        <Button onClick={handleRunAudit} disabled={auditLoading}>
          <RefreshCw className={`h-4 w-4 mr-2 ${auditLoading ? 'animate-spin' : ''}`} />
          {auditLoading ? 'Running Audit...' : 'Run Security Audit'}
        </Button>
      </div>

      {/* Security Score */}
      <Card className="bg-white/60 backdrop-blur-sm border-0 shadow-lg">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Shield className="h-5 w-5" />
            Overall Security Score
          </CardTitle>
          <CardDescription>
            Your password security health at a glance
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center gap-8">
            <div className="relative">
              <div className={`w-32 h-32 rounded-full bg-gradient-to-br ${getScoreBackground(securityScore?.overall || 0)} flex items-center justify-center`}>
                <span className="text-3xl font-bold text-white">
                  {securityScore?.overall || 0}%
                </span>
              </div>
            </div>
            <div className="flex-1 space-y-4">
              <div className="grid grid-cols-2 gap-6">
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">Strong Passwords</span>
                    <span className="text-sm text-muted-foreground">85%</span>
                  </div>
                  <Progress value={85} className="h-2" />
                </div>
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">Unique Passwords</span>
                    <span className="text-sm text-muted-foreground">75%</span>
                  </div>
                  <Progress value={75} className="h-2" />
                </div>
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">Recent Passwords</span>
                    <span className="text-sm text-muted-foreground">60%</span>
                  </div>
                  <Progress value={60} className="h-2" />
                </div>
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">2FA Enabled</span>
                    <span className="text-sm text-muted-foreground">{securityScore?.twoFactorEnabled ? 'Yes' : 'No'}</span>
                  </div>
                  <Progress value={securityScore?.twoFactorEnabled ? 100 : 0} className="h-2" />
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Security Metrics */}
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
        <Card className="bg-white/60 backdrop-blur-sm border-0 shadow-lg">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-lg">
              <div className="p-2 rounded-lg bg-gradient-to-br from-red-500 to-red-600 text-white">
                <AlertTriangle className="h-4 w-4" />
              </div>
              Weak Passwords
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{securityScore?.weakPasswords || 0}</div>
            <p className="text-sm text-muted-foreground">Need immediate attention</p>
          </CardContent>
        </Card>

        <Card className="bg-white/60 backdrop-blur-sm border-0 shadow-lg">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-lg">
              <div className="p-2 rounded-lg bg-gradient-to-br from-orange-500 to-orange-600 text-white">
                <TrendingUp className="h-4 w-4" />
              </div>
              Reused Passwords
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{securityScore?.reusedPasswords || 0}</div>
            <p className="text-sm text-muted-foreground">Should be unique</p>
          </CardContent>
        </Card>

        <Card className="bg-white/60 backdrop-blur-sm border-0 shadow-lg">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-lg">
              <div className="p-2 rounded-lg bg-gradient-to-br from-yellow-500 to-yellow-600 text-white">
                <Clock className="h-4 w-4" />
              </div>
              Old Passwords
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{securityScore?.oldPasswords || 0}</div>
            <p className="text-sm text-muted-foreground">Over 1 year old</p>
          </CardContent>
        </Card>

        <Card className="bg-white/60 backdrop-blur-sm border-0 shadow-lg">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-lg">
              <div className="p-2 rounded-lg bg-gradient-to-br from-purple-500 to-purple-600 text-white">
                <XCircle className="h-4 w-4" />
              </div>
              Compromised
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{securityScore?.compromisedPasswords || 0}</div>
            <p className="text-sm text-muted-foreground">Found in breaches</p>
          </CardContent>
        </Card>
      </div>

      {/* Security Issues */}
      <Card className="bg-white/60 backdrop-blur-sm border-0 shadow-lg">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <AlertTriangle className="h-5 w-5" />
            Security Issues
          </CardTitle>
          <CardDescription>
            Issues that need your attention
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {securityIssues.length === 0 ? (
              <div className="text-center py-8">
                <CheckCircle className="h-12 w-12 text-green-500 mx-auto mb-4" />
                <h3 className="text-lg font-medium">No Security Issues Found</h3>
                <p className="text-muted-foreground">Your passwords are secure!</p>
              </div>
            ) : (
              securityIssues.map((issue) => (
                <div key={issue._id} className="flex items-start gap-4 p-4 rounded-lg bg-white/50 dark:bg-slate-800/50">
                  <div className="mt-1">
                    {getSeverityIcon(issue.severity)}
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <h4 className="font-medium">{issue.website}</h4>
                      <Badge variant={getSeverityColor(issue.severity)}>
                        {issue.severity}
                      </Badge>
                    </div>
                    <p className="text-sm text-muted-foreground mb-2">
                      {issue.description}
                    </p>
                    <p className="text-sm font-medium">
                      Recommendation: {issue.recommendation}
                    </p>
                  </div>
                  <Button variant="outline" size="sm">
                    Fix Now
                  </Button>
                </div>
              ))
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}