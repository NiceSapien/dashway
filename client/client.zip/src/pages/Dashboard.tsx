import { useEffect, useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { 
  Key, 
  FileText, 
  Shield, 
  Download, 
  Plus, 
  AlertTriangle,
  Clock,
  Star,
  TrendingUp
} from "lucide-react"
import { getSecurityScore } from "@/api/security"
import { getPasswords } from "@/api/passwords"
import { useNavigate } from "react-router-dom"
import { useToast } from "@/hooks/useToast"

export function Dashboard() {
  const [securityScore, setSecurityScore] = useState<any>(null)
  const [recentPasswords, setRecentPasswords] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const navigate = useNavigate()
  const { toast } = useToast()

  useEffect(() => {
    const fetchDashboardData = async () => {
      try {
        console.log('Fetching dashboard data...')
        const [scoreResponse, passwordsResponse] = await Promise.all([
          getSecurityScore(),
          getPasswords()
        ])
        
        setSecurityScore(scoreResponse.score)
        setRecentPasswords(passwordsResponse.passwords.slice(0, 5))
      } catch (error) {
        console.error('Error fetching dashboard data:', error)
        toast({
          title: "Error",
          description: "Failed to load dashboard data",
          variant: "destructive",
        })
      } finally {
        setLoading(false)
      }
    }

    fetchDashboardData()
  }, [toast])

  const getScoreColor = (score: number) => {
    if (score >= 80) return "text-green-600"
    if (score >= 60) return "text-yellow-600"
    return "text-red-600"
  }

  const getScoreBackground = (score: number) => {
    if (score >= 80) return "from-green-500 to-emerald-500"
    if (score >= 60) return "from-yellow-500 to-orange-500"
    return "from-red-500 to-pink-500"
  }

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="animate-pulse">
          <div className="h-8 bg-gray-200 rounded w-1/4 mb-4"></div>
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
            {[...Array(4)].map((_, i) => (
              <div key={i} className="h-32 bg-gray-200 rounded-lg"></div>
            ))}
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight bg-gradient-to-r from-slate-900 to-slate-600 dark:from-slate-100 dark:to-slate-400 bg-clip-text text-transparent">
            Welcome back, John
          </h1>
          <p className="text-muted-foreground">
            Here's an overview of your password security
          </p>
        </div>
      </div>

      {/* Security Score */}
      <Card className="bg-white/60 backdrop-blur-sm border-0 shadow-lg">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Shield className="h-5 w-5" />
            Security Score
          </CardTitle>
          <CardDescription>
            Your overall password security health
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center gap-6">
            <div className="relative">
              <div className={`w-24 h-24 rounded-full bg-gradient-to-br ${getScoreBackground(securityScore?.overall || 0)} flex items-center justify-center`}>
                <span className="text-2xl font-bold text-white">
                  {securityScore?.overall || 0}%
                </span>
              </div>
            </div>
            <div className="flex-1 space-y-3">
              <div className="grid grid-cols-2 gap-4">
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-4 w-4 text-red-500" />
                  <span className="text-sm">Weak passwords: {securityScore?.weakPasswords || 0}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Clock className="h-4 w-4 text-yellow-500" />
                  <span className="text-sm">Old passwords: {securityScore?.oldPasswords || 0}</span>
                </div>
                <div className="flex items-center gap-2">
                  <TrendingUp className="h-4 w-4 text-orange-500" />
                  <span className="text-sm">Reused passwords: {securityScore?.reusedPasswords || 0}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Shield className="h-4 w-4 text-green-500" />
                  <span className="text-sm">2FA: {securityScore?.twoFactorEnabled ? 'Enabled' : 'Disabled'}</span>
                </div>
              </div>
              <Button onClick={() => navigate('/security')} className="w-full">
                View Security Dashboard
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Quick Actions */}
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
        <Card className="bg-white/60 backdrop-blur-sm border-0 shadow-lg hover:shadow-xl transition-all duration-300 cursor-pointer group" onClick={() => navigate('/passwords')}>
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-lg">
              <div className="p-2 rounded-lg bg-gradient-to-br from-blue-500 to-blue-600 text-white group-hover:scale-110 transition-transform">
                <Key className="h-4 w-4" />
              </div>
              Add Password
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground">
              Store a new password securely
            </p>
          </CardContent>
        </Card>

        <Card className="bg-white/60 backdrop-blur-sm border-0 shadow-lg hover:shadow-xl transition-all duration-300 cursor-pointer group" onClick={() => navigate('/passwords')}>
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-lg">
              <div className="p-2 rounded-lg bg-gradient-to-br from-green-500 to-green-600 text-white group-hover:scale-110 transition-transform">
                <Shield className="h-4 w-4" />
              </div>
              Generate Password
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground">
              Create a strong, unique password
            </p>
          </CardContent>
        </Card>

        <Card className="bg-white/60 backdrop-blur-sm border-0 shadow-lg hover:shadow-xl transition-all duration-300 cursor-pointer group" onClick={() => navigate('/security')}>
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-lg">
              <div className="p-2 rounded-lg bg-gradient-to-br from-orange-500 to-orange-600 text-white group-hover:scale-110 transition-transform">
                <AlertTriangle className="h-4 w-4" />
              </div>
              Security Checkup
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground">
              Review and fix security issues
            </p>
          </CardContent>
        </Card>

        <Card className="bg-white/60 backdrop-blur-sm border-0 shadow-lg hover:shadow-xl transition-all duration-300 cursor-pointer group" onClick={() => navigate('/settings')}>
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-lg">
              <div className="p-2 rounded-lg bg-gradient-to-br from-purple-500 to-purple-600 text-white group-hover:scale-110 transition-transform">
                <Download className="h-4 w-4" />
              </div>
              Import Data
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground">
              Import passwords from other apps
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Recent Activity */}
      <div className="grid gap-6 md:grid-cols-2">
        <Card className="bg-white/60 backdrop-blur-sm border-0 shadow-lg">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Clock className="h-5 w-5" />
              Recent Passwords
            </CardTitle>
            <CardDescription>
              Your recently accessed passwords
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {recentPasswords.map((password) => (
                <div key={password._id} className="flex items-center gap-3 p-3 rounded-lg bg-white/50 dark:bg-slate-800/50">
                  <div className="w-8 h-8 rounded-full bg-gradient-to-br from-blue-500 to-indigo-500 flex items-center justify-center text-white text-sm font-medium">
                    {password.website.charAt(0).toUpperCase()}
                  </div>
                  <div className="flex-1">
                    <p className="font-medium">{password.website}</p>
                    <p className="text-sm text-muted-foreground">{password.username}</p>
                  </div>
                  <div className="flex items-center gap-2">
                    {password.isFavorite && <Star className="h-4 w-4 text-yellow-500 fill-current" />}
                    <Badge variant={password.strength === 'strong' ? 'default' : password.strength === 'medium' ? 'secondary' : 'destructive'}>
                      {password.strength}
                    </Badge>
                  </div>
                </div>
              ))}
              <Button variant="outline" className="w-full" onClick={() => navigate('/passwords')}>
                View All Passwords
              </Button>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-white/60 backdrop-blur-sm border-0 shadow-lg">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <FileText className="h-5 w-5" />
              Password Health
            </CardTitle>
            <CardDescription>
              Overview of your password security
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div>
                <div className="flex justify-between text-sm mb-2">
                  <span>Strong Passwords</span>
                  <span>75%</span>
                </div>
                <Progress value={75} className="h-2" />
              </div>
              <div>
                <div className="flex justify-between text-sm mb-2">
                  <span>Unique Passwords</span>
                  <span>85%</span>
                </div>
                <Progress value={85} className="h-2" />
              </div>
              <div>
                <div className="flex justify-between text-sm mb-2">
                  <span>Recent Passwords</span>
                  <span>60%</span>
                </div>
                <Progress value={60} className="h-2" />
              </div>
              <Button variant="outline" className="w-full" onClick={() => navigate('/security')}>
                Improve Security
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}