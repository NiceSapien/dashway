import { useEffect, useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import {
  Plus,
  Edit,
  Trash2,
  CreditCard,
  Building2,
  Copy
} from "lucide-react"
import { getPaymentCards, getBankAccounts, PaymentCard, BankAccount } from "@/api/payments"
import { useToast } from "@/hooks/useToast"
import { PaymentDialog } from "@/components/PaymentDialog"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export function Payments() {
  const [cards, setCards] = useState<PaymentCard[]>([])
  const [accounts, setAccounts] = useState<BankAccount[]>([])
  const [loading, setLoading] = useState(true)
  const [selectedPayment, setSelectedPayment] = useState<PaymentCard | BankAccount | null>(null)
  const [showDialog, setShowDialog] = useState(false)
  const [dialogType, setDialogType] = useState<'card' | 'account'>('card')
  const { toast } = useToast()

  useEffect(() => {
    const fetchPayments = async () => {
      try {
        console.log('Fetching payment methods...')
        const [cardsResponse, accountsResponse] = await Promise.all([
          getPaymentCards(),
          getBankAccounts()
        ])
        setCards(cardsResponse.cards)
        setAccounts(accountsResponse.accounts)
      } catch (error) {
        console.error('Error fetching payment methods:', error)
        toast({
          title: "Error",
          description: "Failed to load payment methods",
          variant: "destructive",
        })
      } finally {
        setLoading(false)
      }
    }

    fetchPayments()
  }, [toast])

  const handleEdit = (payment: PaymentCard | BankAccount, type: 'card' | 'account') => {
    setSelectedPayment(payment)
    setDialogType(type)
    setShowDialog(true)
  }

  const handleAddNew = (type: 'card' | 'account') => {
    setSelectedPayment(null)
    setDialogType(type)
    setShowDialog(true)
  }

  const copyToClipboard = async (text: string, type: string) => {
    try {
      await navigator.clipboard.writeText(text)
      toast({
        title: "Copied!",
        description: `${type} copied to clipboard`,
      })
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to copy to clipboard",
        variant: "destructive",
      })
    }
  }

  const getCardTypeColor = (cardType: string) => {
    switch (cardType) {
      case 'visa': return 'from-blue-500 to-blue-600'
      case 'mastercard': return 'from-red-500 to-red-600'
      case 'amex': return 'from-green-500 to-green-600'
      case 'discover': return 'from-orange-500 to-orange-600'
      default: return 'from-gray-500 to-gray-600'
    }
  }

  const getAccountTypeColor = (accountType: string) => {
    switch (accountType) {
      case 'checking': return 'from-blue-500 to-blue-600'
      case 'savings': return 'from-green-500 to-green-600'
      case 'business': return 'from-purple-500 to-purple-600'
      default: return 'from-gray-500 to-gray-600'
    }
  }

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="animate-pulse">
          <div className="h-8 bg-gray-200 rounded w-1/4 mb-4"></div>
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {[...Array(4)].map((_, i) => (
              <div key={i} className="h-48 bg-gray-200 rounded-lg"></div>
            ))}
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight bg-gradient-to-r from-slate-900 to-slate-600 dark:from-slate-100 dark:to-slate-400 bg-clip-text text-transparent">
            Payment Methods
          </h1>
          <p className="text-muted-foreground">
            Manage your credit cards and bank accounts
          </p>
        </div>
      </div>

      <Tabs defaultValue="cards" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="cards">Credit Cards</TabsTrigger>
          <TabsTrigger value="accounts">Bank Accounts</TabsTrigger>
        </TabsList>

        <TabsContent value="cards" className="space-y-6">
          <div className="flex justify-end">
            <Button onClick={() => handleAddNew('card')}>
              <Plus className="h-4 w-4 mr-2" />
              Add Card
            </Button>
          </div>

          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {cards.map((card) => (
              <Card key={card._id} className="bg-white/60 backdrop-blur-sm border-0 shadow-lg hover:shadow-xl transition-all duration-300 overflow-hidden">
                <div className={`h-4 bg-gradient-to-r ${getCardTypeColor(card.cardType)}`} />
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className={`w-12 h-8 rounded bg-gradient-to-r ${getCardTypeColor(card.cardType)} flex items-center justify-center text-white text-xs font-bold`}>
                        {card.cardType.toUpperCase()}
                      </div>
                      <div>
                        <CardTitle className="text-lg">{card.nickname}</CardTitle>
                        <CardDescription>{card.cardholderName}</CardDescription>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Button variant="ghost" size="sm" onClick={() => handleEdit(card, 'card')}>
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button variant="ghost" size="sm">
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <span className="text-lg font-mono tracking-wider">{card.cardNumber}</span>
                      <Button variant="ghost" size="sm" onClick={() => copyToClipboard(card.cardNumber.replace(/\*/g, ''), 'Card number')}>
                        <Copy className="h-4 w-4" />
                      </Button>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4 text-sm">
                      <div>
                        <p className="text-muted-foreground">Expires</p>
                        <p className="font-medium">{card.expirationDate}</p>
                      </div>
                      <div>
                        <p className="text-muted-foreground">CVV</p>
                        <p className="font-medium">{card.cvv}</p>
                      </div>
                    </div>

                    <div className="pt-2 border-t">
                      <p className="text-xs text-muted-foreground">
                        {card.billingAddress.city}, {card.billingAddress.state}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        Last modified {new Date(card.lastModified).toLocaleDateString()}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="accounts" className="space-y-6">
          <div className="flex justify-end">
            <Button onClick={() => handleAddNew('account')}>
              <Plus className="h-4 w-4 mr-2" />
              Add Account
            </Button>
          </div>

          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {accounts.map((account) => (
              <Card key={account._id} className="bg-white/60 backdrop-blur-sm border-0 shadow-lg hover:shadow-xl transition-all duration-300">
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className={`w-12 h-12 rounded-full bg-gradient-to-r ${getAccountTypeColor(account.accountType)} flex items-center justify-center text-white`}>
                        <Building2 className="h-6 w-6" />
                      </div>
                      <div>
                        <CardTitle className="text-lg">{account.nickname}</CardTitle>
                        <CardDescription>{account.bankName}</CardDescription>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Button variant="ghost" size="sm" onClick={() => handleEdit(account, 'account')}>
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button variant="ghost" size="sm">
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <Badge variant="secondary" className="capitalize">
                        {account.accountType}
                      </Badge>
                    </div>

                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-muted-foreground">Account Number</span>
                        <div className="flex items-center gap-2">
                          <span className="font-mono">{account.accountNumber}</span>
                          <Button variant="ghost" size="sm" onClick={() => copyToClipboard(account.accountNumber.replace(/\*/g, ''), 'Account number')}>
                            <Copy className="h-3 w-3" />
                          </Button>
                        </div>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-muted-foreground">Routing Number</span>
                        <div className="flex items-center gap-2">
                          <span className="font-mono">{account.routingNumber}</span>
                          <Button variant="ghost" size="sm" onClick={() => copyToClipboard(account.routingNumber, 'Routing number')}>
                            <Copy className="h-3 w-3" />
                          </Button>
                        </div>
                      </div>
                    </div>

                    <div className="pt-2 border-t">
                      <p className="text-sm font-medium">{account.accountHolderName}</p>
                      <p className="text-xs text-muted-foreground">
                        Last modified {new Date(account.lastModified).toLocaleDateString()}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>

      <PaymentDialog
        open={showDialog}
        onOpenChange={setShowDialog}
        payment={selectedPayment}
        type={dialogType}
        onSave={() => {
          setShowDialog(false)
          // Refresh payment methods list
        }}
      />
    </div>
  )
}