import { useEffect, useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import {
  Search,
  Plus,
  Edit,
  Trash2,
  Star,
  FileText,
  Filter
} from "lucide-react"
import { getNotes, SecureNote } from "@/api/notes"
import { useToast } from "@/hooks/useToast"
import { NoteDialog } from "@/components/NoteDialog"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export function SecureNotes() {
  const [notes, setNotes] = useState<SecureNote[]>([])
  const [filteredNotes, setFilteredNotes] = useState<SecureNote[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedNote, setSelectedNote] = useState<SecureNote | null>(null)
  const [showNoteDialog, setShowNoteDialog] = useState(false)
  const [activeCategory, setActiveCategory] = useState("all")
  const { toast } = useToast()

  useEffect(() => {
    const fetchNotes = async () => {
      try {
        console.log('Fetching notes...')
        const response = await getNotes()
        setNotes(response.notes)
        setFilteredNotes(response.notes)
      } catch (error) {
        console.error('Error fetching notes:', error)
        toast({
          title: "Error",
          description: "Failed to load notes",
          variant: "destructive",
        })
      } finally {
        setLoading(false)
      }
    }

    fetchNotes()
  }, [toast])

  useEffect(() => {
    let filtered = notes.filter(note =>
      note.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      note.content.toLowerCase().includes(searchTerm.toLowerCase()) ||
      note.tags.some(tag => tag.toLowerCase().includes(searchTerm.toLowerCase()))
    )

    if (activeCategory !== "all") {
      filtered = filtered.filter(note => note.category === activeCategory)
    }

    setFilteredNotes(filtered)
  }, [searchTerm, notes, activeCategory])

  const handleEdit = (note: SecureNote) => {
    setSelectedNote(note)
    setShowNoteDialog(true)
  }

  const handleAddNew = () => {
    setSelectedNote(null)
    setShowNoteDialog(true)
  }

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'personal': return 'bg-blue-500'
      case 'work': return 'bg-green-500'
      case 'financial': return 'bg-yellow-500'
      case 'other': return 'bg-purple-500'
      default: return 'bg-gray-500'
    }
  }

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="animate-pulse">
          <div className="h-8 bg-gray-200 rounded w-1/4 mb-4"></div>
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {[...Array(6)].map((_, i) => (
              <div key={i} className="h-48 bg-gray-200 rounded-lg"></div>
            ))}
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight bg-gradient-to-r from-slate-900 to-slate-600 dark:from-slate-100 dark:to-slate-400 bg-clip-text text-transparent">
            Secure Notes
          </h1>
          <p className="text-muted-foreground">
            Store sensitive information securely
          </p>
        </div>
        <Button onClick={handleAddNew}>
          <Plus className="h-4 w-4 mr-2" />
          Add Note
        </Button>
      </div>

      <Card className="bg-white/60 backdrop-blur-sm border-0 shadow-lg">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                placeholder="Search notes..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" size="sm">
                  <Filter className="h-4 w-4 mr-2" />
                  Filter
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent>
                <DropdownMenuItem>All Notes</DropdownMenuItem>
                <DropdownMenuItem>Favorites</DropdownMenuItem>
                <DropdownMenuItem>Recently Modified</DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </CardHeader>
        <CardContent>
          <Tabs value={activeCategory} onValueChange={setActiveCategory} className="w-full">
            <TabsList className="grid w-full grid-cols-5">
              <TabsTrigger value="all">All</TabsTrigger>
              <TabsTrigger value="personal">Personal</TabsTrigger>
              <TabsTrigger value="work">Work</TabsTrigger>
              <TabsTrigger value="financial">Financial</TabsTrigger>
              <TabsTrigger value="other">Other</TabsTrigger>
            </TabsList>
            <TabsContent value={activeCategory} className="mt-6">
              <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                {filteredNotes.map((note) => (
                  <Card key={note._id} className="bg-white/50 dark:bg-slate-800/50 hover:bg-white/70 dark:hover:bg-slate-800/70 transition-colors">
                    <CardHeader className="pb-3">
                      <div className="flex items-start justify-between">
                        <div className="flex items-center gap-2">
                          <div className={`w-3 h-3 rounded-full ${getCategoryColor(note.category)}`} />
                          <div className="flex-1">
                            <h3 className="font-medium line-clamp-1">{note.title}</h3>
                            <p className="text-xs text-muted-foreground capitalize">{note.category}</p>
                          </div>
                        </div>
                        <div className="flex items-center gap-1">
                          {note.isFavorite && <Star className="h-4 w-4 text-yellow-500 fill-current" />}
                          <Button variant="ghost" size="sm" onClick={() => handleEdit(note)}>
                            <Edit className="h-3 w-3" />
                          </Button>
                          <Button variant="ghost" size="sm">
                            <Trash2 className="h-3 w-3" />
                          </Button>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-3">
                        <p className="text-sm text-muted-foreground line-clamp-3">
                          {note.content}
                        </p>
                        <div className="flex flex-wrap gap-1">
                          {note.tags.slice(0, 3).map((tag) => (
                            <Badge key={tag} variant="secondary" className="text-xs">
                              {tag}
                            </Badge>
                          ))}
                          {note.tags.length > 3 && (
                            <Badge variant="secondary" className="text-xs">
                              +{note.tags.length - 3}
                            </Badge>
                          )}
                        </div>
                        <p className="text-xs text-muted-foreground">
                          Modified {new Date(note.lastModified).toLocaleDateString()}
                        </p>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>

      <NoteDialog
        open={showNoteDialog}
        onOpenChange={setShowNoteDialog}
        note={selectedNote}
        onSave={() => {
          setShowNoteDialog(false)
          // Refresh notes list
        }}
      />
    </div>
  )
}